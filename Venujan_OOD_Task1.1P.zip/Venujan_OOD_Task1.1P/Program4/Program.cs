﻿/*
 * 
 * 
int height = 13;
if (height <= 12)
{
    Console.WriteLine("Low bridge: ");
    Console.WriteLine("proceed with caution.");
}


Console.WriteLine("--------------------------------------------");

int sum = 21;
if ( sum != 20 )
{
Console.WriteLine ("You win ");
}
else
{
Console.WriteLine ("You lose ");
Console.WriteLine ("the prize.");
}


Console.WriteLine("--------------------------------------------");

int sum = 7;
if ( sum > 20 ) {
Console.WriteLine ("You win ");
} else {
Console.WriteLine ("You lose ");                //nochanges
}
Console.WriteLine("the prize.");

Console.WriteLine("--------------------------------------------");



*/

