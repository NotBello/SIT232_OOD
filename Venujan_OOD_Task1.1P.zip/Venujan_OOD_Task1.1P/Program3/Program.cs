﻿/*
using System;

int number = 50;
if (number == 50)
{
    Console.WriteLine("Number is 50");
}

Console.WriteLine("--------------------------------------------");

int number1 = 60;
if (number1 >= 50 && number1 <= 100)
{
    Console.WriteLine("Number is more than or equal to 50 and less than or equal to 100");
}

Console.WriteLine("--------------------------------------------");

public class Score
{
    public static void Main(string[] args)
    {
        double score = 40;
        if (score > 40)
        {
            Console.WriteLine("You passed the exam!");
        }
        else if (score < 40)
        {
            Console.WriteLine("You failed the exam!");
        }
    }
}

Console.WriteLine("--------------------------------------------");

switch (n) {
    case 1:
        Console.WriteLine("The number is 1");
        break;
    case 2:
        Console.WriteLine("The number is 2");
        break;
    default:
        Console.WriteLine("The number is not 1 or 2");
        break;
}

Console.WriteLine("--------------------------------------------");

switch (n) {
    case 1:
        Console.WriteLine("The number is 1");
        break;
    case 2:
        Console.WriteLine("The number is 2");
        break;
    default:
        Console.WriteLine("The number is not 1 or 2");
        break;
}

Console.WriteLine("--------------------------------------------");

switch (n) {
case 1:
    Console.WriteLine (“A”); 
    break;
case2: 
    Console.WriteLine (“B”); 
    break;
default: 
    Console.WriteLine (“C”); 
    break;
}
Console.WriteLine("--------------------------------------------");



*/