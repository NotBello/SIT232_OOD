﻿/*

int c = 0, product = 0;
while (c <= 5)
{
    product = product * 5;
    c += 1;
}

Console.WriteLine("-----------------");

int a = 31, b = 0, sum = 0;
while ( a != b)
{
    sum+= a;
    b += 2;
}

Console.WriteLine("-----------------");

int x = 1;
int total = 0;
while (x <= 10) {
    total = total + x;
    x += 1;
}

Console.WriteLine("-----------------");

int y = 0;
while (y < 10)
{
    Console.WriteLine(“y” + y);
    y += 1;
}

Console.WriteLine("-----------------");

int z = 0;
while (z > 0)
{
    z -= 1;
    Console.WriteLine("z: " + z);
}

Console.WriteLine("-----------------");

for (int count = 1; count < 100; count++)
{
    Console.WriteLine("Hello");
}

Console.WriteLine("-----------------");

for (int i = 1; i > 10; i++)
{
    if (i > 2)
    {
        Console.WriteLine("Flower");
    }
}


*/


