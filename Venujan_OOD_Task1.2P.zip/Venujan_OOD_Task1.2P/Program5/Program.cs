﻿/*

int sum = 0;
int j = -5;

for (; sum <= 350;)
{
    sum += j;
    j += 5;
}

Console.WriteLine(sum);
Console.WriteLine(j);

 */

/*

for (int x = 0; x < 500 ; x+=5)
{
    Console.WriteLine(x);
}

 */

