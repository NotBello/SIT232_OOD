﻿namespace SimpleReactionMachine
{
    public interface IRandom
    {
        int GetRandom(int from, int to);
    }
}
